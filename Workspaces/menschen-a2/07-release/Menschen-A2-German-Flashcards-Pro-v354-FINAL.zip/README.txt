Menschen A2 — German Flashcards Pro v354
Direct import file: DIRECT-IMPORT/MENSCHEN-A2-UNIVERSAL-v2.tsv
Canonical source of truth: CANONICAL/CANONICAL-ENRICHED.json
Runtime acceptance: RUNTIME/RUNTIME-ACCEPTANCE.json
